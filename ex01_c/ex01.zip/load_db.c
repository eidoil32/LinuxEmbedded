#include <stdio.h>
#include "libmanager.h"

int main(int argc, char **argv) {
	forceLoad();
	return 0;
}